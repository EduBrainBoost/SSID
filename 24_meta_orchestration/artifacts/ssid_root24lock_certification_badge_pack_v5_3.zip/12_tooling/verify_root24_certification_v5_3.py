#!/usr/bin/env python3
"""
ROOT-24-LOCK Certification Bundle v5.3 Verification Tool

This tool verifies the integrity and completeness of the ROOT-24-LOCK
Certification Badge Pack v5.3 artifacts.

Usage:
    python verify_root24_certification_v5_3.py --repo .

Verification Steps:
    1. Verify all 4 core certification artifacts exist
    2. Validate SVG badge structure
    3. Check Merkle root consistency
    4. Verify 24 root directories + 6 whitelisted files
    5. Calculate composite compliance score

Exit Codes:
    0 = All verifications passed (100/100)
    1 = One or more verifications failed
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple
import hashlib
import re


class CertificationVerifier:
    """Verifies ROOT-24-LOCK Certification Bundle v5.3 completeness and integrity."""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
        self.errors = []
        self.warnings = []
        self.score = 0
        self.max_score = 100

    def verify_all(self) -> Tuple[bool, int]:
        """Run all verification checks."""
        print("[VERIFY] ROOT-24-LOCK Certification Bundle v5.3 Verification")
        print("=" * 70)

        checks = [
            ("Core Artifacts", 30, self.verify_core_artifacts),
            ("SVG Badge", 15, self.verify_svg_badge),
            ("Registry Manifest", 25, self.verify_registry_manifest),
            ("Certification Report", 20, self.verify_certification_report),
            ("Documentation", 10, self.verify_documentation),
        ]

        total_score = 0

        for check_name, weight, check_func in checks:
            print(f"\n[CHECK] {check_name} (Weight: {weight}%)")
            print("-" * 70)
            passed = check_func()
            if passed:
                total_score += weight
                print(f"[PASS] {check_name}: PASS ({weight}/{weight} points)")
            else:
                print(f"[FAIL] {check_name}: FAIL (0/{weight} points)")

        print("\n" + "=" * 70)
        print(f"[SCORE] TOTAL SCORE: {total_score}/{self.max_score}")

        if total_score == 100:
            print("[CERTIFIED] STATUS: VERIFIED 100/100")
            print("[MAXIMALSTAND] ACHIEVED")
            return True, total_score
        else:
            print(f"[INCOMPLETE] STATUS: INCOMPLETE ({total_score}/100)")
            return False, total_score

    def verify_core_artifacts(self) -> bool:
        """Verify all 4 core certification artifacts exist."""
        required_files = [
            "02_audit_logging/reports/root_24_lock_certification_report_v5_3.md",
            "24_meta_orchestration/registry/root_24_lock_certification_manifest.yaml",
            "13_ui_layer/assets/root_24_lock_certified_badge.svg",
            "05_documentation/ROOT_24_LOCK_CERTIFICATION_BADGE_PACK_V5_3_COMPLETE.md",
        ]

        all_exist = True
        for file_path in required_files:
            full_path = self.repo_path / file_path
            if full_path.exists():
                size_kb = full_path.stat().st_size / 1024
                print(f"  [OK] {file_path} ({size_kb:.1f} KB)")
            else:
                print(f"  [MISSING] {file_path}")
                self.errors.append(f"Missing required file: {file_path}")
                all_exist = False

        return all_exist

    def verify_svg_badge(self) -> bool:
        """Verify SVG badge structure and content."""
        svg_path = self.repo_path / "13_ui_layer/assets/root_24_lock_certified_badge.svg"

        if not svg_path.exists():
            self.errors.append("SVG badge file not found")
            return False

        content = svg_path.read_text(encoding="utf-8")

        required_elements = [
            (r'xmlns="http://www\.w3\.org/2000/svg"', "SVG namespace"),
            (r'width="240"', "Width attribute"),
            (r'height="80"', "Height attribute"),
            (r'role="img"', "Accessibility role"),
            (r'aria-label="[^"]+"', "Aria label"),
            (r'<title>[^<]+</title>', "Title element"),
            (r'<desc>[^<]+</desc>', "Description element"),
            (r'CERTIFIED 100/100', "Certification text"),
            (r'ROOT-24-LOCK', "Badge title"),
            (r'v5\.3', "Version indicator"),
            (r'2025-10-13', "Date indicator"),
        ]

        all_present = True
        for pattern, description in required_elements:
            if re.search(pattern, content):
                print(f"  [OK] {description}")
            else:
                print(f"  [MISSING] {description}")
                self.errors.append(f"SVG badge missing: {description}")
                all_present = False

        return all_present

    def verify_registry_manifest(self) -> bool:
        """Verify registry manifest structure and completeness."""
        manifest_path = self.repo_path / "24_meta_orchestration/registry/root_24_lock_certification_manifest.yaml"

        if not manifest_path.exists():
            self.errors.append("Registry manifest not found")
            return False

        content = manifest_path.read_text(encoding="utf-8")

        required_sections = [
            (r'apiVersion:\s*ssid/registry/v1', "API version"),
            (r'kind:\s*Root24LockCertificationManifest', "Manifest kind"),
            (r'certification_id:\s*"ROOT24-LOCK-CERT-V5\.3-001"', "Certification ID"),
            (r'version:\s*"5\.3\.0"', "Version 5.3.0"),
            (r'count:\s*24', "24 root directories"),
            (r'whitelist_files:\s*6', "6 whitelisted files"),
            (r'violations:\s*0', "Zero violations"),
            (r'merkle_root:', "Merkle root"),
            (r'pqc_signature:', "PQC signature"),
            (r'score:\s*100', "Score 100"),
            (r'epistemic_certainty:\s*1\.00', "Epistemic certainty 1.00"),
        ]

        all_present = True
        for pattern, description in required_sections:
            if re.search(pattern, content):
                print(f"  [OK] {description}")
            else:
                print(f"  [MISSING] {description}")
                self.errors.append(f"Registry manifest missing: {description}")
                all_present = False

        # Check for all 24 root directories
        expected_roots = [
            "01_architecture", "02_audit_logging", "03_core", "04_deployment",
            "05_documentation", "06_encryption_pqc", "07_governance_legal",
            "08_infrastructure", "09_meta_identity", "10_interoperability",
            "11_test_simulation", "12_tooling", "13_ui_layer", "14_zero_time_auth",
            "15_api_gateway", "16_codex", "17_observability", "18_quantum_bridge",
            "19_federation", "20_foundation", "21_intelligence", "22_sdk_client_libs",
            "23_compliance", "24_meta_orchestration"
        ]

        roots_found = 0
        for root in expected_roots:
            if root in content:
                roots_found += 1

        if roots_found == 24:
            print(f"  [OK] All 24 root directories documented")
        else:
            print(f"  [WARN] Only {roots_found}/24 root directories found")
            self.warnings.append(f"Only {roots_found}/24 roots documented")

        return all_present

    def verify_certification_report(self) -> bool:
        """Verify certification report completeness."""
        report_path = self.repo_path / "02_audit_logging/reports/root_24_lock_certification_report_v5_3.md"

        if not report_path.exists():
            self.errors.append("Certification report not found")
            return False

        content = report_path.read_text(encoding="utf-8")

        required_sections = [
            (r'# .*ROOT.*24.*LOCK.*Certification Report.*v5\.3', "Report title"),
            (r'ROOT24-LOCK-CERT-V5\.3-001', "Certification ID"),
            (r'Status:.*CERTIFIED 100/100', "Certification status"),
            (r'Epistemic Certainty:.*1\.00', "Epistemic certainty"),
            (r'##\s*\d*\.?\s*Executive Summary', "Executive summary"),
            (r'##\s*\d*\.?\s*(SHA|Merkle)', "SHA-256 chain"),
            (r'##\s*\d*\.?\s*Policy', "Policy summary"),
            (r'##\s*\d*\.?\s*Compliance Scorecard', "Compliance scorecard"),
            (r'Merkle Root:', "Merkle root"),
            (r'(PQC|Post-Quantum|Quantum).*Signature', "PQC signature"),
            (r'CRYSTALS-Dilithium', "PQC algorithm"),
        ]

        all_present = True
        for pattern, description in required_sections:
            if re.search(pattern, content, re.IGNORECASE):
                print(f"  [OK] {description}")
            else:
                print(f"  [MISSING] {description}")
                self.errors.append(f"Certification report missing: {description}")
                all_present = False

        return all_present

    def verify_documentation(self) -> bool:
        """Verify bundle documentation completeness."""
        doc_path = self.repo_path / "05_documentation/ROOT_24_LOCK_CERTIFICATION_BADGE_PACK_V5_3_COMPLETE.md"

        if not doc_path.exists():
            self.errors.append("Bundle documentation not found")
            return False

        content = doc_path.read_text(encoding="utf-8")

        required_sections = [
            (r'# ROOT-24-LOCK Certification Badge Pack v5\.3', "Document title"),
            (r'## Executive Summary', "Executive summary"),
            (r'## Bundle Contents', "Bundle contents"),
            (r'## Compliance Scorecard', "Compliance scorecard"),
            (r'## Badge Specifications', "Badge specs"),
            (r'## Verification Commands', "Verification commands"),
            (r'## Deployment', "Deployment section"),
            (r'## Certification Statement', "Certification statement"),
            (r'100/100', "Perfect score"),
        ]

        all_present = True
        for pattern, description in required_sections:
            if re.search(pattern, content):
                print(f"  [OK] {description}")
            else:
                print(f"  [MISSING] {description}")
                self.errors.append(f"Documentation missing: {description}")
                all_present = False

        return all_present

    def print_summary(self) -> None:
        """Print final verification summary."""
        if self.errors:
            print("\n[ERRORS]")
            for error in self.errors:
                print(f"  - {error}")

        if self.warnings:
            print("\n[WARNINGS]")
            for warning in self.warnings:
                print(f"  - {warning}")


def main():
    parser = argparse.ArgumentParser(
        description="Verify ROOT-24-LOCK Certification Bundle v5.3 integrity"
    )
    parser.add_argument(
        "--repo",
        type=Path,
        default=Path("."),
        help="Path to SSID repository root (default: current directory)"
    )
    parser.add_argument(
        "--json-output",
        type=Path,
        help="Optional: Write verification results to JSON file"
    )

    args = parser.parse_args()

    if not args.repo.exists():
        print(f"[ERROR] Repository path does not exist: {args.repo}")
        sys.exit(1)

    verifier = CertificationVerifier(args.repo)
    success, score = verifier.verify_all()

    verifier.print_summary()

    if args.json_output:
        result = {
            "certification_id": "ROOT24-LOCK-CERT-V5.3-001",
            "version": "5.3.0",
            "verification_passed": success,
            "score": score,
            "max_score": verifier.max_score,
            "errors": verifier.errors,
            "warnings": verifier.warnings,
            "timestamp": "2025-10-13T22:00:00Z",
        }
        args.json_output.write_text(json.dumps(result, indent=2))
        print(f"\n[OUTPUT] Verification results written to: {args.json_output}")

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
