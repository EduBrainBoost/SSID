# Shard_03_Zugang_Berechtigungen

AI/ML & Intelligenz für Rollen, Rechte

**Domain:** access
