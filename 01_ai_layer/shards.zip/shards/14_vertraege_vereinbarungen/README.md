# Shard_14_Vertraege_Vereinbarungen

AI/ML & Intelligenz für Contracts

**Domain:** contracts
