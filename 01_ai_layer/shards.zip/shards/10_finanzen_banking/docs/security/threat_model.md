# Threat Model - Shard_10_Finanzen_Banking

## Assets
- Konten, Zahlungen

## Threats
1. PII exposure
2. Hash collision

## Mitigations
- Hash-only storage
- Runtime PII detection
