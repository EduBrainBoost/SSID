# Finance risk scoring
