# Changelog

## [1.0.0] - 2025-10-05

### Added
- Initial release
