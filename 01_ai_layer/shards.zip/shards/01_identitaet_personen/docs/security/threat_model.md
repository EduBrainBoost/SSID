# Threat Model - Shard_01_Identitaet_Personen

## Assets
- DIDs, Ausweise, Profile

## Threats
1. PII exposure
2. Hash collision

## Mitigations
- Hash-only storage
- Runtime PII detection
