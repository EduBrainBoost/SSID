# Rust Implementation - Shard_01_Identitaet_Personen

**Status:** Planned
