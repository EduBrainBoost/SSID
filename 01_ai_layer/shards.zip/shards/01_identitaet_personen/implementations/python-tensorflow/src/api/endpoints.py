# API endpoints
from fastapi import APIRouter

router = APIRouter()
