# Threat Model - Shard_06_Bildung_Qualifikationen

## Assets
- Zeugnisse, Kurse

## Threats
1. PII exposure
2. Hash collision

## Mitigations
- Hash-only storage
- Runtime PII detection
