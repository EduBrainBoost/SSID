# Shard_06_Bildung_Qualifikationen

AI/ML & Intelligenz für Zeugnisse, Kurse

**Domain:** education
