# Shard_08_Mobilitaet_Fahrzeuge

AI/ML & Intelligenz für Führerschein, KFZ

**Domain:** mobility
