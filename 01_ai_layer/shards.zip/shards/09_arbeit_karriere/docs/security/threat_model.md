# Threat Model - Shard_09_Arbeit_Karriere

## Assets
- Arbeitsverträge

## Threats
1. PII exposure
2. Hash collision

## Mitigations
- Hash-only storage
- Runtime PII detection
