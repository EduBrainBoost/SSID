import json, os, yaml
from pathlib import Path

BASE = Path(os.path.expanduser("~/Documents/Github/SSID"))

def test_registry_manifest_v5_exists():
    """Verify unified registry manifest v5 exists."""
    assert (BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml").exists()

def test_blueprint_5_manifest_exists():
    """Verify Blueprint 5.0 manifest exists."""
    assert (BASE / "16_codex/structure/blueprint_5.0_manifest.yaml").exists()

def test_consolidation_report_exists():
    """Verify version consolidation report exists."""
    assert (BASE / "02_audit_logging/reports/version_consolidation_v9_v12.md").exists()

def test_all_version_registry_entries_exist():
    """Verify all v9-v12 registry entries are present."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    assert "versions" in registry
    assert "v9.0" in registry["versions"]
    assert "v10.0" in registry["versions"]
    assert "v11.0" in registry["versions"]
    assert "v12.0" in registry["versions"]

def test_hash_chain_integrity():
    """Verify merkle root references for all versions."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    # Check v9-v11 have single merkle roots
    for v in ["v9.0", "v10.0", "v11.0"]:
        assert "merkle_root_sha512" in registry["versions"][v]
        assert len(registry["versions"][v]["merkle_root_sha512"]) == 128  # SHA-512 hex length

    # Check v12 has dual merkle roots
    assert "merkle_roots" in registry["versions"]["v12.0"]
    assert "sha512" in registry["versions"]["v12.0"]["merkle_roots"]
    assert "blake3" in registry["versions"]["v12.0"]["merkle_roots"]

def test_policies_consistent():
    """Verify policy references are consistent across versions."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    # Check root_artifact_guard exists in v9.0
    v9_policies = registry["versions"]["v9.0"]["policies"]
    assert any("root_artifact_guard.rego" in p for p in v9_policies)

    # Check continuum policies in v10.0
    v10_policies = registry["versions"]["v10.0"]["policies"]
    assert any("continuum" in p for p in v10_policies)

def test_documentation_complete():
    """Verify all required documentation exists."""
    docs = [
        "02_audit_logging/reports/version_consolidation_v9_v12.md",
        "16_codex/structure/blueprint_5.0_manifest.yaml",
        "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    ]
    for doc in docs:
        assert (BASE / doc).exists(), f"Missing: {doc}"

def test_test_coverage_progression():
    """Verify test coverage increases across versions."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    v9_tests = registry["versions"]["v9.0"]["tests_passed"]
    v10_tests = registry["versions"]["v10.0"]["tests_passed"]
    v11_tests = registry["versions"]["v11.0"]["tests_passed"]
    v12_tests = registry["versions"]["v12.0"]["tests_passed"]

    assert v10_tests >= v9_tests
    assert v11_tests >= v10_tests
    assert v12_tests >= v11_tests

def test_blueprint_5_capabilities():
    """Verify Blueprint 5.0 defines all required capabilities."""
    blueprint_path = BASE / "16_codex/structure/blueprint_5.0_manifest.yaml"
    with open(blueprint_path, 'r', encoding='utf-8') as f:
        blueprint = yaml.safe_load(f)

    assert "capabilities" in blueprint
    assert "must_have" in blueprint["capabilities"]
    assert "should_have" in blueprint["capabilities"]
    assert "nice_to_have" in blueprint["capabilities"]

    # Check critical capabilities exist
    must_have = blueprint["capabilities"]["must_have"]
    capability_names = [c["capability"] for c in must_have]
    assert "Root-24-LOCK Structure" in capability_names
    assert "SAFE-FIX Enforcement" in capability_names
    assert "PQC Cryptography (NIST Level 3)" in capability_names

def test_compliance_mappings_complete():
    """Verify all compliance frameworks are mapped."""
    blueprint_path = BASE / "16_codex/structure/blueprint_5.0_manifest.yaml"
    with open(blueprint_path, 'r', encoding='utf-8') as f:
        blueprint = yaml.safe_load(f)

    assert "compliance_mapping" in blueprint
    assert "gdpr" in blueprint["compliance_mapping"]
    assert "mica" in blueprint["compliance_mapping"]
    assert "eidas" in blueprint["compliance_mapping"]
    assert "dora" in blueprint["compliance_mapping"]

def test_final_certification_score():
    """Verify final consolidated score is 400/400."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    assert registry["metadata"]["overall_score"] == "400/400"
    assert registry["final_status"]["overall_score"] == "400/400"
    assert registry["final_status"]["certification"] == "BLUEPRINT_5.0_READY"

def test_interfederation_active():
    """Verify v12 interfederation is active."""
    registry_path = BASE / "24_meta_orchestration/registry/registry_manifest_v5.yaml"
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = yaml.safe_load(f)

    v12 = registry["versions"]["v12.0"]
    assert v12["status"] == "INTERFEDERATION_ACTIVE"
    assert "interfederation" in v12
    assert v12["interfederation"]["semantic_resonance"] >= 0.97
    assert v12["interfederation"]["reflexive_symmetry"] == 1.0
